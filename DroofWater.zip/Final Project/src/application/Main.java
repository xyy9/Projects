package application;
	
import java.util.ArrayList;
import java.util.Collections;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;


public class Main extends Application {
	public Stage stage;
	private Scene menu,game,instruction,rank;
	private Button Start,Instruction,Rank,Sound,Home,Restart1,Exit,Next,Back1,Back2,Play,Save;
	private GridPane gp;
	Timeline gameLoop;
	MediaPlayer BGM;
	Pane root;
	int numb = 10,level = 1,sum = 85,combo = 0,score = 0;
	String Name0,Name1="???",Name2="???",Name3="???",Name4="???",Name5="???";
	
	Image start_back = new Image(Main.class.getResourceAsStream("start_back.jpg"));
	Image game_back = new Image(Main.class.getResourceAsStream("game_back.jpg"));
	Image rank_back = new Image(Main.class.getResourceAsStream("rank_back.jpg"));
	Image ins_back = new Image(Main.class.getResourceAsStream("Instruction.png"));
	Image water0 = new Image(Main.class.getResourceAsStream("0.png"));
	Image water1 = new Image(Main.class.getResourceAsStream("1.png"));
	Image water2 = new Image(Main.class.getResourceAsStream("2.png"));
	Image water3 = new Image(Main.class.getResourceAsStream("3.png"));
	Image water4 = new Image(Main.class.getResourceAsStream("4.png"));
	Image up = new Image(Main.class.getResourceAsStream("up.png"));
	Image down = new Image(Main.class.getResourceAsStream("down.png"));
	Image left = new Image(Main.class.getResourceAsStream("left.png"));
	Image right = new Image(Main.class.getResourceAsStream("right.png"));
	Media media_BGM = new Media(getClass().getResource("bgm.mp3").toString());
	
	ArrayList<Water>waters= new ArrayList<>();
	ArrayList<Integer>types= new ArrayList<>();
	ArrayList<Drop> drops= new ArrayList<>();
	ArrayList<Integer>type2 = new ArrayList<>();
	ArrayList<Integer>ns = new ArrayList<>();
	ArrayList<Integer>ms = new ArrayList<>();
	
	int remb[][] = new int [6][6];
	int score00[][] = new int [6][6];
	int s[][] = new int [2][6];
	@Override
	public void start(Stage primaryStage) {
		stage = primaryStage;
		BGM = new MediaPlayer(media_BGM);
		try {
			menu = new Scene(FXMLLoader.load(getClass().getResource("start.fxml")));
			
			Label B1 = (Label)menu.lookup("#back");
			B1.setGraphic(new ImageView(start_back));
			
			Start = (Button) menu.lookup("#Start");
			Start.setOnMouseClicked(new EventHandler<Event>() {
				public void handle(Event event) {
					random(sum);
					print();
					stage.setScene(game);
				}
			});
			
			Exit = (Button) menu.lookup("#Exit");
			Exit.setOnMouseClicked(new EventHandler<Event>() {
				public void handle(Event event) {
					Platform.exit();
				}
			});
			
			Instruction = (Button) menu.lookup("#Instruction");
			Instruction.setOnMouseClicked(new EventHandler<Event>() {
				public void handle(Event event) {
					primaryStage.setScene(instruction);
				}
			});
			
			Rank = (Button) menu.lookup("#Rank");
			Rank.setOnMouseClicked(new EventHandler<Event>() {
				public void handle(Event event) {
					primaryStage.setScene(rank);
				}
			});
			
			Sound = (Button) menu.lookup("#sound");
			Sound.setOnMouseClicked(new EventHandler<Event>() {
				public void handle(Event event) {
					BGM.stop();
				}
			});
			
			instruction = new Scene(FXMLLoader.load(getClass().getResource("Instruction.fxml")));
			
			Label B2 = (Label)instruction.lookup("#back");
			B2.setGraphic(new ImageView(ins_back));
			
			Back1 = (Button) instruction.lookup("#Back");
			Back1.setOnMouseClicked(new EventHandler<Event>() {
				public void handle(Event event) {
					initial();
					primaryStage.setScene(menu);
				}
			});
			
			Play = (Button) instruction.lookup("#play");
			Play.setOnMouseClicked(new EventHandler<Event>() {
				public void handle(Event event) {
					initial();
					random(sum);
					print();
					primaryStage.setScene(game);
				}
			});
			
			rank = new Scene(FXMLLoader.load(getClass().getResource("Rank.fxml")));
			
			Back2 = (Button) rank.lookup("#Back");
			Back2.setOnMouseClicked(new EventHandler<Event>() {
				public void handle(Event event) {
					primaryStage.setScene(menu);
				}
			});
			
			Label B3 = (Label)rank.lookup("#back");
			B3.setGraphic(new ImageView(rank_back));
			
			Label name1 = (Label)rank.lookup("#name1");
			name1.setText(Name1);
			Label name2 = (Label)rank.lookup("#name2");
			name2.setText(Name2);
			Label name3 = (Label)rank.lookup("#name3");
			name3.setText(Name3);
			Label name4 = (Label)rank.lookup("#name4");
			name4.setText(Name4);
			Label name5 = (Label)rank.lookup("#name5");
			name5.setText(Name5);
			
			Label s1 = (Label)rank.lookup("#s1");
			s1.setText("level:"+String.valueOf(s[0][0])+"   score:"+String.valueOf(s[1][0]));
			Label s2 = (Label)rank.lookup("#s2");
			s2.setText("level:"+String.valueOf(s[0][1])+"   score:"+String.valueOf(s[1][1]));
			Label s3 = (Label)rank.lookup("#s3");
			s3.setText("level:"+String.valueOf(s[0][2])+"   score:"+String.valueOf(s[1][2]));
			Label s4 = (Label)rank.lookup("#s4");
			s4.setText("level:"+String.valueOf(s[0][3])+"   score:"+String.valueOf(s[1][3]));
			Label s5 = (Label)rank.lookup("#s5");
			s5.setText("level:"+String.valueOf(s[0][4])+"   score:"+String.valueOf(s[1][4]));
			
			game = new Scene(FXMLLoader.load(getClass().getResource("game.fxml")));
			
			Label B4 = (Label)game.lookup("#back");
			B4.setGraphic(new ImageView(game_back));
			
			Home = (Button) game.lookup("#Home");
			Home.setOnMouseClicked(new EventHandler<Event>() {
				public void handle(Event event) {
					stage.setScene(menu);
					initial();
				}
			});
			
			Restart1 = (Button) game.lookup("#Restart");
			Restart1.setOnMouseClicked(new EventHandler<Event>() {
				public void handle(Event event) {
					initial();
					random(sum);
					print();
					primaryStage.setScene(game);
				}
			});
			
			Save= (Button) game.lookup("#save");
			Save.setOnMouseClicked(new EventHandler<Event>() {
				public void handle(Event event) {
					TextField name = (TextField) game.lookup("#name");
					Name0 = name.getText();
					s[0][5] = level;
					s[1][5] = score;
					rank();
					
					Label name1 = (Label)rank.lookup("#name1");
					name1.setText(Name1);
					Label name2 = (Label)rank.lookup("#name2");
					name2.setText(Name2);
					Label name3 = (Label)rank.lookup("#name3");
					name3.setText(Name3);
					Label name4 = (Label)rank.lookup("#name4");
					name4.setText(Name4);
					Label name5 = (Label)rank.lookup("#name5");
					name5.setText(Name5);
					
					Label s1 = (Label)rank.lookup("#s1");
					s1.setText("level:"+String.valueOf(s[0][0])+"   score:"+String.valueOf(s[1][0]));
					Label s2 = (Label)rank.lookup("#s2");
					s2.setText("level:"+String.valueOf(s[0][1])+"   score:"+String.valueOf(s[1][1]));
					Label s3 = (Label)rank.lookup("#s3");
					s3.setText("level:"+String.valueOf(s[0][2])+"   score:"+String.valueOf(s[1][2]));
					Label s4 = (Label)rank.lookup("#s4");
					s4.setText("level:"+String.valueOf(s[0][3])+"   score:"+String.valueOf(s[1][3]));
					Label s5 = (Label)rank.lookup("#s5");
					s5.setText("level:"+String.valueOf(s[0][4])+"   score:"+String.valueOf(s[1][4]));
					
					initial();
					primaryStage.setScene(rank);
				}
			});
			
			VBox vv = (VBox)game.lookup("#vv");
			vv.setVisible(false);
			
			VBox gameover = (VBox)game.lookup("#gameover");
			gameover.setVisible(false);
			
			root = (Pane)game.lookup("#root");
			
			gp = (GridPane)game.lookup("#gp");
			
			BGM.play();
			primaryStage.setScene(menu);
			primaryStage.setResizable(false);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public Image getImageByType(int type) {
		switch(type) {
		case 1:return water1;
		case 2:return water2;
		case 3:return water3;
		case 4:return water4;
		}
		return water0;
	}
	
	public void print() {
		Label Level = (Label)game.lookup("#Level");
		Level.setText("Level:  "+String.valueOf(level));
		Label Numb = (Label)game.lookup("#numb");
		if(combo >= 5) {
			numb = numb + combo -5;
		}
		Numb.setText(String.valueOf(numb));
		combo = 0;
		check();
		waters.clear();
		gp.getChildren().clear();
		root.getChildren().clear();
		for (int i = 0;i<6;i++) {
			for (int j = 0;j<6;j++) {
				Water wt = new Water(water1,types.get(i*6+j));
				final int X = i, Y = j;
				wt.setImage(getImageByType(
						wt.type
							));
				waters.add(wt);
				GridPane.setHalignment(wt, HPos.CENTER);
				gp.add(wt,i,j);
				wt.setOnMouseClicked(new EventHandler<Event>() {
					public void handle(Event event) {
						numb--;
						Numb.setText(String.valueOf(numb));
						wt.type++;
						types.set(X*6+Y,types.get(X*6+Y)+1);
						remb[Y][X]++;
						wt.setImage(getImageByType(
								wt.type
									));
						/*for(int n = 0;n<6;n++) {
							for(int m = 0;m<6;m++) {
								System.out.print(remb[n][m]+",");
							}
							System.out.print("\n");
						}
						System.out.print("\n\n");*/
						if (wt.type == 5) {
							types.set(X*6+Y, 0);
							printwt();
							boom(X,Y);	
							Action();
							if(numb == 0) {
								numb -=1;
								level -=1;
								check();
							}
						}
						else {
							Label Combo = (Label)game.lookup("#combo");
							Combo.setText(" ");
							if(numb == 0) {
								VBox gameover = (VBox)game.lookup("#gameover");
								gameover.setVisible(true);
							}
						}
					}});
			}
		}
	}
	
	public void boom(int n,int m) {
		int a = 0;
		score += score00[m][n];
		combo++;
		Label Combo = (Label)game.lookup("#combo");
		Combo.setText("combo "+combo);
		Label Score = (Label)game.lookup("#score");
		Score.setText("score: "+score);
		remb[m][n] = 0;
		types.set(n*6+m, 0);
		addup(n,m);
		for (a=1;m-a>=0;a++) {//up
			if(remb[m-a][n]!=0) {
				remb[m-a][n]++;
				if(remb[m-a][n]==5) {
					remb[m-a][n]=0;
				}
				break;
			}
		}
		ns.add(n);
		ms.add(m-a);
		adddown(n,m);
		for (a=1;m+a<=5;a++) {//down
			if(remb[m+a][n]!=0) {
				remb[m+a][n]++;
				if(remb[m+a][n]==5) {
					remb[m+a][n]=0;
				}
				break;
			}
		}	
		ns.add(n);
		ms.add(m+a);
		addleft(n,m);
		for (a=1;n-a>=0;a++) {//left
			if(remb[m][n-a]!=0) {
				remb[m][n-a]++;
				if(remb[m][n-a]==5) {
					remb[m][n-a]=0;
				}
				break;
			}
		}	
		ns.add(n-a);
		ms.add(m);
		addright(n,m);
		for (a=1;n+a<=5;a++) {//right
			if(remb[m][n+a]!=0) {
				remb[m][n+a]++;
				if(remb[m][n+a]==5) {
					remb[m][n+a]=0;
				}
				break;
			}
		}	
		ns.add(n+a);
		ms.add(m);	
	}
	
	void Action() {
		gameLoop = new Timeline(new KeyFrame(Duration.millis(5),new EventHandler<>() {
			public void handle(ActionEvent e) {
				for(int i = 0;i<drops.size();i++) {
					if(type2.get(i)==1) {//up
						drops.get(i).positionY-=1;
						drops.get(i).drop.setTranslateY(drops.get(i).positionY);
						if(drops.get(i).positionY<=0) {
							type2.remove(i);
							drops.remove(i);
							root.getChildren().remove(i);
							ns.remove(i);
							ms.remove(i);
							printwt();
							i = -1;
						}
						else if(drops.get(i).positionY<=ms.get(i)*65+25) {
							type2.remove(i);
							drops.remove(i);
							root.getChildren().remove(i);
							types.set(ns.get(i)*6+ms.get(i), types.get(ns.get(i)*6+ms.get(i))+1);
							if (types.get(ns.get(i)*6+ms.get(i))==5) {
								boom(ns.get(i),ms.get(i));
							}
							ns.remove(i);
							ms.remove(i);
							printwt();
							i = -1;
						}
					}
					else if(type2.get(i)==2) {//down
						drops.get(i).positionY+=1;
						drops.get(i).drop.setTranslateY(drops.get(i).positionY);
						if(drops.get(i).positionY>=380) {
							type2.remove(i);
							drops.remove(i);
							root.getChildren().remove(i);
							ns.remove(i);
							ms.remove(i);
							printwt();
							i = -1;
						}
						else if(drops.get(i).positionY>=ms.get(i)*65+25) {
							type2.remove(i);
							drops.remove(i);
							root.getChildren().remove(i);
							types.set(ns.get(i)*6+ms.get(i), types.get(ns.get(i)*6+ms.get(i))+1);
							if (types.get(ns.get(i)*6+ms.get(i))==5) {
								boom(ns.get(i),ms.get(i));
							}
							ns.remove(i);
							ms.remove(i);
							printwt();
							i = -1;
						}
					}
					else if(type2.get(i)==3) {//left
						drops.get(i).positionX-=1;
						drops.get(i).drop.setTranslateX(drops.get(i).positionX);
						if(drops.get(i).positionX<=0) {
							type2.remove(i);
							drops.remove(i);
							root.getChildren().remove(i);
							ns.remove(i);
							ms.remove(i);
							printwt();
							i = -1;
						}
						else if(drops.get(i).positionX<=(ns.get(i))*65+25) {
							type2.remove(i);
							drops.remove(i);
							root.getChildren().remove(i);
							types.set(ns.get(i)*6+ms.get(i), types.get(ns.get(i)*6+ms.get(i))+1);
							if (types.get(ns.get(i)*6+ms.get(i))==5) {
								boom(ns.get(i),ms.get(i));
							}
							ns.remove(i);
							ms.remove(i);
							printwt();
							i = -1;
						}
					}
					else if(type2.get(i)==4) {//right
						drops.get(i).positionX+=1;
						drops.get(i).drop.setTranslateX(drops.get(i).positionX);
						if(drops.get(i).positionX>=380) {
							type2.remove(i);
							drops.remove(i);
							root.getChildren().remove(i);
							ns.remove(i);
							ms.remove(i);
							printwt();
							i = -1;
						}
						else if(drops.get(i).positionX>=(ns.get(i))*65+25) {
							type2.remove(i);
							drops.remove(i);
							root.getChildren().remove(i);
							types.set(ns.get(i)*6+ms.get(i), types.get(ns.get(i)*6+ms.get(i))+1);
							if (types.get(ns.get(i)*6+ms.get(i))==5) {
								boom(ns.get(i),ms.get(i));						
							}
							ns.remove(i);
							ms.remove(i);
							printwt();
							i = -1;
						}
					}
				}
				if(drops.size() == 0) {
					gameLoop.stop();
					print();
				}
			}
		}));
		gameLoop.setCycleCount(-1);
		gameLoop.play();
	}
	
	void printwt() {
		gp.getChildren().clear();
		for (int i = 0;i<6;i++) {
			for(int j = 0;j<6;j++) {
				Water wt = new Water(water0,types.get(i*6+j));
				wt.setImage(getImageByType(
						wt.type
						));
				GridPane.setHalignment(wt, HPos.CENTER);
				gp.add(wt,i,j);
			}
		}
	}
	
	void addup(int n, int m) {
		Drop drop = new Drop(up,1,n*65+25,m*65+25);
		drops.add(drop);
		type2.add(1);
		root.getChildren().add(drop.drop);
	}
	
	void adddown(int n, int m) {
		Drop drop = new Drop(down,2,n*65+25,m*65+25);
		drops.add(drop);
		type2.add(2);
		root.getChildren().add(drop.drop);
	}	
	
	void addleft(int n, int m) {
		Drop drop = new Drop(left,3,n*65+25,m*65+25);
		drops.add(drop);
		type2.add(3);
		root.getChildren().add(drop.drop);
	}	
	
	void addright(int n, int m) {
		Drop drop = new Drop(right,4,n*65+25,m*65+25);
		drops.add(drop);
		type2.add(4);
		root.getChildren().add(drop.drop);
	}
	
	void random(int s) {
		//sum-time
		int ss = s;
		while (ss > 0) {
			types.clear();
			ss = s;
			for (int i = 0;i<36;i++) {
				int ii = (int)(Math.random()*5);
				if (ss <= ii) {
					types.add(ss);
					for (;i<35;i++) {
						types.add(0);
					}
				}
				ss -= ii;
				if(ss > 0) {
					types.add(ii);
				}
			}
		}
		Collections.shuffle(types);
		for (int ii = 0;ii<6;ii++) {
			for (int jj = 0;jj<6;jj++) {
				remb[jj][ii] = types.get(ii*6+jj);
				score00[jj][ii] = (5-types.get(ii*6+jj))*6;
			}
		}
	}
	
	void check() {
		int a = 0;
		for(int i = 0;i<36;i++) {
			if(types.get(i)==0) {
				a++;
			}
		}
		if(a == 36) {
			level++;
			numb++;
			VBox vv = (VBox)game.lookup("#vv");
			vv.setVisible(true);
			if(level<=5) {
				sum = 90-level*5;
			}
			else {
				sum = 65;
			}
			Label Combo = (Label)game.lookup("#combo");
			Combo.setText(" ");
			Next = (Button)game.lookup("#Next");
			Next.setOnMouseClicked(new EventHandler<Event>() {
				public void handle(Event event) {
					vv.setVisible(false);
					random(sum);
					print();
				}
			});
		}
		if(a!=36&&numb<=0) {
			numb++;
			level++;
			VBox gameover = (VBox)game.lookup("#gameover");
			gameover.setVisible(true);
		}
	}
	
	void initial() {
		gp.getChildren().clear();
		BGM.play();
		root.getChildren().clear();
		numb = 10;
		level = 1;
		sum = 85;
		combo = 0;
		score = 0;
		waters.clear();
		types.clear();
		drops.clear();
		type2.clear();
		ns.clear();
		ms.clear();
		VBox vv = (VBox)game.lookup("#vv");
		vv.setVisible(false);
		VBox gameover = (VBox)game.lookup("#gameover");
		gameover.setVisible(false);
		Label Combo = (Label)game.lookup("#combo");
		Combo.setText("");
		Label Score = (Label)game.lookup("#score");
		Score.setText("score: "+0);
		TextField name = (TextField) game.lookup("#name");
		name.clear();
	}
	
	void rank() {
		if(s[1][5]>=s[1][0]) {
			Name5 = Name4;
			Name4 = Name3;
			Name3 = Name2;
			Name2 = Name1;
			Name1 = Name0;
			s[0][4] = s[0][3];
			s[1][4] = s[1][3];
			s[0][3] = s[0][2];
			s[1][3] = s[1][2];
			s[0][2] = s[0][1];
			s[1][2] = s[1][1];
			s[0][1] = s[0][0];
			s[1][1] = s[1][0];
			s[0][0] = s[0][5];
			s[1][0] = s[1][5];
		}
		else if(s[1][5]>=s[1][1]) {
			Name5 = Name4;
			Name4 = Name3;
			Name3 = Name2;
			Name2 = Name0;
			s[0][4] = s[0][3];
			s[1][4] = s[1][3];
			s[0][3] = s[0][2];
			s[1][3] = s[1][2];
			s[0][2] = s[0][1];
			s[1][2] = s[1][1];
			s[0][1] = s[0][5];
			s[1][1] = s[1][5];
		}
		else if(s[1][5]>=s[1][2]) {
			Name5 = Name4;
			Name4 = Name3;
			Name3 = Name0;
			s[0][4] = s[0][3];
			s[1][4] = s[1][3];
			s[0][3] = s[0][2];
			s[1][3] = s[1][2];
			s[0][2] = s[0][5];
			s[1][2] = s[1][5];
		}
		else if(s[1][5]>=s[1][3]) {
			Name5 = Name4;
			Name4 = Name0;
			s[0][4] = s[0][3];
			s[1][4] = s[1][3];
			s[0][3] = s[0][5];
			s[1][3] = s[1][5];
		}
		else if(s[1][5]>=s[1][4]) {
			Name5 = Name0;
			s[0][4] = s[0][5];
			s[1][4] = s[1][5];
		}
	}
	public static void main(String[] args) {
		launch(args);
	}
}
