package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Water extends ImageView{
	public int type,water;
	public Water(Image im,int type) {
		super(im);
		this.type = type;
		setFitWidth(60);
		setFitHeight(60);
	}
}
