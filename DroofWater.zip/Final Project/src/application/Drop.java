package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Drop extends ImageView{
	int type;
	double positionX,positionY;
	ImageView drop;
	public Drop (Image drop,int type,double positionX,double positionY) {
		this.type = type;
		this.positionX=positionX;
		this.positionY=positionY;
		this.drop = new ImageView(drop);
		this.drop.setTranslateX(positionX);
		this.drop.setTranslateY(positionY);
	}

}
